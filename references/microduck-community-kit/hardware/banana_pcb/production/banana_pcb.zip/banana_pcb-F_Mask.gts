G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu22.04.1*
G04 #@! TF.CreationDate,2026-09-27T11:51:59+08:00*
G04 #@! TF.ProjectId,banana_pcb,62616e61-6e61-45f7-9063-622e6b696361,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu22.04.1) date 2026-09-27 11:51:59*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.300000X1.200000X-2.200000X1.200000X2.200000X-1.200000X2.200000X-1.200000X-2.200000X0*%
%ADD11C,3.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J3*
X140150000Y-89840000D03*
X144150000Y-89840000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X129170000Y-89250000D03*
G04 #@! TD*
G04 #@! TO.C,J2*
X162970000Y-89250000D03*
G04 #@! TD*
M02*
